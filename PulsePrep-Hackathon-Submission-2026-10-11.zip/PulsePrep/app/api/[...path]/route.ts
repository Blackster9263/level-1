import {ConvexError} from 'convex/values';
import {api} from '@/convex/_generated/api';
import {publicRoles} from '@/lib/data';
import {cloudConfig,serverAuth} from '@/lib/cloud-config';
const ai={available:false,cacheOnly:true,model:'Illustrative demo scorer'};
const statusFor=(code:string)=>code==='UNAUTHENTICATED'?401:code==='NOT_FOUND'?404:code==='RATE_LIMIT'||code==='SESSION_LIMIT'?429:['ALREADY_ANSWERED','SESSION_FINISHED','REIMPORT_GITHUB','IMPORT_CANCELLED'].includes(code)?409:400;
async function handle(request:Request){const headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
  try{
    const path=new URL(request.url).pathname.slice(4),config=cloudConfig();
    if(request.method==='GET'&&path==='/roles')return Response.json({roles:publicRoles,levels:['fresher','0-1'],ai},{headers});
    if(!config.convexUrl||!config.convexSiteUrl||!config.siteUrl)return Response.json({error:{code:'CLOUD_SETUP_REQUIRED',message:'The Convex backend is not connected yet.'}},{status:503,headers});
    if(request.method!=='GET'&&request.headers.get('origin')!==config.siteUrl)return Response.json({error:{code:'INVALID_ORIGIN',message:'Please submit from this website.'}},{status:403,headers});
    const auth=serverAuth();if(!await auth.isAuthenticated())return Response.json({error:{code:'UNAUTHENTICATED',message:'Your session expired. Sign in again to continue.'}},{status:401,headers});
    let result:unknown;
    if(request.method==='GET'){
      if(path==='/sessions')result={sessions:await auth.fetchAuthQuery(api.interviews.list,{})};
      else if(/^\/sessions\/[^/]+$/.test(path))result={session:await auth.fetchAuthQuery(api.interviews.get,{id:decodeURIComponent(path.split('/')[2])})};
      else if(/^\/reports\/[^/]+$/.test(path))result={report:await auth.fetchAuthQuery(api.interviews.report,{id:decodeURIComponent(path.split('/')[2])})};
      else return Response.json({error:{code:'NOT_FOUND',message:'Not found.'}},{status:404,headers});
    }else if(request.method==='POST'){
      if(Number(request.headers.get('content-length')||0)>64000)return Response.json({error:{code:'TOO_LARGE',message:'Your request is too large.'}},{status:413,headers});
      const raw=await request.text();if(raw.length>64000)return Response.json({error:{code:'TOO_LARGE',message:'Your request is too large.'}},{status:413,headers});
      let input:unknown;try{input=JSON.parse(raw||'{}');}catch{return Response.json({error:{code:'INVALID_INPUT',message:'Invalid request.'}},{status:400,headers});}
      if(path==='/references/github'){const username=(input as {username?:unknown})?.username;if(typeof username!=='string')return Response.json({error:{code:'INVALID_INPUT',message:'Enter a GitHub username.'}},{status:400,headers});result=await auth.fetchAuthAction(api.github.importProjects,{username});}
      else if(path==='/sessions')result={session:await auth.fetchAuthMutation(api.interviews.create,{input})};
      else if(path==='/history/clear')result=await auth.fetchAuthMutation(api.interviews.clearHistory,{});
      else {const match=path.match(/^\/sessions\/([^/]+)\/(answers|skip|finish)$/);if(!match)return Response.json({error:{code:'NOT_FOUND',message:'Not found.'}},{status:404,headers});const id=decodeURIComponent(match[1]);result=match[2]==='answers'?await auth.fetchAuthMutation(api.interviews.answer,{id,input}):match[2]==='skip'?await auth.fetchAuthMutation(api.interviews.skip,{id,input}):{report:await auth.fetchAuthMutation(api.interviews.finish,{id})};}
    }else return Response.json({error:{code:'NOT_FOUND',message:'Not found.'}},{status:404,headers});
    return Response.json(result,{headers});
  }catch(error){if(error instanceof ConvexError){let data:unknown=error.data;if(typeof data==='string'){try{data=JSON.parse(data);}catch{data=null;}}if(data&&typeof data==='object'&&'code' in data&&'message' in data&&typeof data.code==='string'&&typeof data.message==='string')return Response.json({error:{code:data.code,message:data.message}},{status:statusFor(data.code),headers});}return Response.json({error:{code:'SERVER_ERROR',message:'We could not complete that action. Please retry or sign in again.'}},{status:503,headers});}
}
export const GET=handle;export const POST=handle;
