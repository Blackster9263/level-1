import {serverAuth,cloudConfig} from '@/lib/cloud-config';
async function handle(request:Request){if(!cloudConfig().convexUrl)return Response.json({error:{code:'CLOUD_SETUP_REQUIRED',message:'The Convex backend is not connected yet.'}},{status:503});try{const handlers=serverAuth().handler;return request.method==='GET'?await handlers.GET(request):await handlers.POST(request);}catch{return Response.json({error:{code:'AUTH_UNAVAILABLE',message:'Sign-in is temporarily unavailable. Please retry.'}},{status:503});}}
export const GET=handle;export const POST=handle;
