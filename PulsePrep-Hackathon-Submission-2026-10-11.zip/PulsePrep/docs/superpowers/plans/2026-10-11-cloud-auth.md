# Cloud release implementation plan

> **For agentic workers:** Use superpowers:executing-plans for inline implementation, with one independent final review. Record unavailable external verification rather than claim completion.

**Goal:** Preserve PulsePrep's features while adding real account ownership using Cloudflare, Convex and Better Auth.

**Architecture:** Existing React UI with same-origin API/auth handlers on a Cloudflare Worker. Atomic, owner-scoped Convex functions and persistent reviewed reference snapshots. Official Better Auth component and compatible dependency versions.

**Tech stack:** Vinext, React, TypeScript, Convex 1.46.0, @convex-dev/better-auth 0.12.5, Better Auth 1.6.33, existing Zod/jsPDF/Lucide.

**Spec:** `../specs/2026-10-11-cloud-auth-design.md`

## Global constraints

No Netlify, D1, local-data uploads, real AI claims, invented deployment IDs or committed secrets. Preserve `../level-1` and `sources/`.

**Ponytail (explicitly requested):** reuse the existing UI, domain scoring and installed dependencies. Finish and verify the requested account boundary; do not add speculative integrations, analytics, billing or a second database.

## Review focus

- An expired, forged or missing session cannot access personal APIs.
- A second user cannot see reports, previews or browser drafts from the first.
- Concurrent answer/finish calls cannot alter completed results.
- Restarting Workers cannot lose reviewed GitHub previews.
- Missing backend configuration cannot masquerade as a working online app.

## Tasks

- [x] Backend: write RED tests for ownership, lifecycle, reporting, quotas and preview expiry; implement schema/functions and official auth component; run the full cloud suite.
- [x] Frontend: wire same-origin auth/API handlers and sign-in UI; scope drafts, reactive history and deletion to the signed-in user; typecheck and build.
- [ ] Release: obtain authorized Convex configuration, publish backend, configure exact frontend origin/secrets, review, package and publish Worker; verify actual public signup/interview/report/signout.

## Progress

- User confirmed original Convex + Better Auth stack and requested continued work toward the final product.
- Cloudflare-backed Sites identity persisted; no deployment or backend data exists yet.
- User confirmed they do not have a Convex account/project. Account creation and user sign-in remain required; no credentials or deployment IDs are invented.
- Fresh verification: `npm test` passes seven Node domain/storage tests and seven Vitest backend/auth/proxy tests; `npm run typecheck` and `npm run build` pass. Expected rejected-password, hostile-origin and short-password auth logs are intentional negative tests.
- Independent read-only review found three Important issues. Each was reproduced RED then fixed and verified GREEN: actual signed Convex JWT is rejected after sign-out via active Better Auth session lookup; scoped browser storage/request revisions reject stale account callbacks; deletion-generation invalidation prevents running imports from recreating previews after history deletion.
- Minor preview-retention wording now distinguishes 30-minute usability from deletion on later imports/history clearing. No automatic 30-minute physical deletion is claimed.
- Main-agent desktop/mobile setup smoke (1440×1000 and 390×844) passes page identity, meaningful content, no framework overlay or relevant console errors, refresh/layout and honest 503 setup-required responses. Real deployed account/interview/report browser flows remain untested.
- Sites' Windows build helper could not resolve npm.cmd; the unchanged framework build entrypoint succeeds via `npm run build`. Installed Git lacks `git-remote-https.exe`, so remote source synchronization is not claimed. The local source/download is retained, and the original laptop checkout remains clean at `00aac68`.
