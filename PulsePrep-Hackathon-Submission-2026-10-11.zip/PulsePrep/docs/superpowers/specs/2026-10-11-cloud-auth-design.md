# PulsePrep cloud release

User-confirmed stack: Cloudflare hosting, Convex backend/database, Better Auth. No Netlify or D1. Preserve the existing `../level-1` laptop app and all synced references unchanged.

## Architecture

Reuse the tested React interface and scoring logic. Use the supplied Vinext/Cloudflare Worker hosting integration, because the existing Next.js app needs same-origin API/auth routes rather than static-only Pages hosting. Convex stores interviews, reports and reviewed reference snapshots. Better Auth runs in the official Convex component; `/api/auth/*` proxies it through the frontend origin. The public homepage requires sign-in before personal data operations.

Start with email/password signup, signin and signout. Email addresses are not verified and no email recovery is advertised until a mail service is configured. Label this hackathon limitation in the account UI. Google/GitHub OAuth requires separate provider credentials and is not represented as connected. Use server-validated sessions, exact trusted origins, secure production cookies and persistent auth rate limiting. Never accept a client-supplied owner ID. All Convex data functions authorize the token identity and scope records to that identity; foreign records return not found. No account linking without explicit configuration.

Keep keyless scoring visibly illustrative. Original question banks and the reviewed GitHub/manual LinkedIn/manual coding-topic references continue working. GitHub import is a server action with bounded response parsing, timeouts, a required User-Agent, fixed upstream URLs and durable owner-bound reviewed snapshots. Beginning an interview cannot silently re-fetch reviewed metadata. Full-mock evaluations remain hidden in server responses until completion. Mutations atomically enforce pending-answer and completed-session guards.

Namespace browser drafts by authenticated user and clear the active in-memory workspace on signout. Unsigned visitors cannot create, read or mutate interviews. History is reactive through Convex. Explain that reports are saved to the signed-in account, not merely this browser. Provide authenticated history deletion and a clear note that credentials are handled by Better Auth.

## Publication

Use a fresh Convex deployment; do not upload local SQLite or previous answers. Keep auth secrets in backend environment configuration, never source or browser bundles. Set Convex SITE_URL and trusted origin to the literal deployed frontend URL. Configure the public Convex cloud/site URLs as frontend Worker runtime bindings. No paid AI calls, analytics/session replay, uploads, R2 or billing are needed for this release. Do not fake a backend when credentials are missing: show setup-required state and do not call it a completed online product.

## Verification

Tests must exercise anonymous denial, two-user isolation, duplicate and post-finish submissions, hidden full-mock answers, report scoring, reviewed-snapshot ownership/expiry, input limits, durable quotas and deletion. Check signup, signin, signout and draft isolation in rendered desktop/mobile UI where the backend is available. Run typecheck, the complete cloud test suite and a Cloudflare Worker build. Production login/data smoke tests and public reachability are release gates; absent credentials are explicitly reported as incomplete.

## Prerequisites

Cloudflare-backed Sites registered as `appgprj_6acaaa561fec819184157d5c884c2e72`; registration is not deployment. Convex is not authenticated/configured in the current environment. User sign-in or a user-provided local secret-file path is required for backend publication. Never request secret values in chat.
