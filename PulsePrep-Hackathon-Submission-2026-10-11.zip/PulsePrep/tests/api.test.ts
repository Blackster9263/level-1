import {beforeEach,it,expect,vi} from 'vitest';
import {ConvexError} from 'convex/values';
const state=vi.hoisted(()=>({ready:true,authenticated:true,query:vi.fn()}));
vi.mock('@/lib/cloud-config',()=>({cloudConfig:()=>({convexUrl:state.ready?'https://test.convex.cloud':'',convexSiteUrl:'https://test.convex.site',siteUrl:'https://pulseprep.example'}),serverAuth:()=>({isAuthenticated:async()=>state.authenticated,fetchAuthQuery:state.query})}));
import {GET,POST} from '../app/api/[...path]/route';
beforeEach(()=>{state.ready=true;state.authenticated=true;state.query.mockReset();});
it('proxy fails closed on missing configuration, missing identity and cross-site writes',async()=>{
  state.ready=false;expect((await GET(new Request('https://pulseprep.example/api/sessions'))).status).toBe(503);
  state.ready=true;state.authenticated=false;expect((await GET(new Request('https://pulseprep.example/api/sessions'))).status).toBe(401);
  expect((await POST(new Request('https://pulseprep.example/api/sessions',{method:'POST',headers:{Origin:'https://untrusted.example'},body:'{}'}))).status).toBe(403);
});
it('proxy preserves safe Convex error codes across object and serialized error data',async()=>{
  for(const value of [{code:'IMPORT_CANCELLED',message:'Import again.'},JSON.stringify({code:'IMPORT_CANCELLED',message:'Import again.'})]){
    state.query.mockRejectedValueOnce(new ConvexError(value));
    const response=await GET(new Request('https://pulseprep.example/api/sessions'));
    expect(response.status).toBe(409);expect(await response.json()).toEqual({error:{code:'IMPORT_CANCELLED',message:'Import again.'}});
  }
});
