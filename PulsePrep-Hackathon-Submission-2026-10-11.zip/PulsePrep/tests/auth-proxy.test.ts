import {it,expect,vi} from 'vitest';

vi.mock('@/lib/cloud-config',()=>({
  cloudConfig:()=>({convexUrl:'https://test.convex.cloud'}),
  serverAuth:()=>({handler:{GET:()=>fetch('data:application/json,null')}}),
}));
import {GET} from '../app/api/auth/[...all]/route';

it('auth proxy returns mutable response headers for the Cloudflare router',async()=>{
  const response=await GET(new Request('https://pulseprep.example/api/auth/get-session'));
  expect(response.status).toBe(200);
  expect(()=>response.headers.set('Vary','RSC')).not.toThrow();
  expect(await response.json()).toBeNull();
});
