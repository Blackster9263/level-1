const test=require('node:test'),assert=require('node:assert/strict');
const memory=new Map();global.window={localStorage:{getItem:k=>memory.get(k)??null,setItem:(k,v)=>memory.set(k,v),removeItem:k=>memory.delete(k),key:i=>[...memory.keys()][i]??null,get length(){return memory.size}}};
const {storage,configureStorage,api}=require('../lib/client.ts');
test('anonymous storage is disabled and users cannot restore one another’s drafts',()=>{assert.equal(storage.write('draft:q1','private'),false);configureStorage('alice');storage.write('draft:q1','alice answer');configureStorage('bob');assert.equal(storage.read('draft:q1'),null);storage.write('draft:q1','bob answer');configureStorage('alice');assert.equal(storage.read('draft:q1'),'alice answer');storage.clear();assert.equal(storage.read('draft:q1'),null);configureStorage('bob');assert.equal(storage.read('draft:q1'),'bob answer');configureStorage(null);assert.equal(storage.read('draft:q1'),null);});

test('delayed responses and captured callbacks cannot disturb the next account',async()=>{
  configureStorage('alice');const alice=storage.capture();alice.write('activeSessionId','alice-active');
  const originalFetch=global.fetch;let release;
  global.fetch=()=>new Promise(resolve=>{release=resolve;});
  try{
    const pending=api.create({roleId:'frontend_developer',mode:'full',level:'fresher',demo:true});
    configureStorage('bob');storage.write('activeSessionId','bob-active');
    release(new Response(JSON.stringify({session:{id:'alice-response'}}),{status:200,headers:{'Content-Type':'application/json'}}));
    await assert.rejects(pending,e=>e.code==='ACCOUNT_CHANGED');
    assert.equal(alice.write('activeSessionId','late-alice'),false);
    alice.clear();assert.equal(storage.read('activeSessionId'),'bob-active');
    configureStorage('alice');assert.equal(storage.read('activeSessionId'),null);
  }finally{global.fetch=originalFetch;configureStorage(null);}
});
