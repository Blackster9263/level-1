import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {runInNewContext} from 'node:vm';
import {describe,expect,it} from 'vitest';
import RootLayout from '../app/layout';

describe('theme applied before hydration',()=>{
  // A missing provider, wrong storage key or forced light theme breaks the visible preference.
  it.each([
    {stored:null,systemDark:true,want:'dark'},
    {stored:null,systemDark:false,want:'light'},
    {stored:'light',systemDark:true,want:'light'},
    {stored:'dark',systemDark:false,want:'dark'},
  ])('resolves $stored with systemDark=$systemDark to $want',({stored,systemDark,want})=>{
    const html=renderToStaticMarkup(createElement(RootLayout,{children:createElement('p',null,'Workspace')}));
    const scripts=[...html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)];
    expect(scripts.length).toBeGreaterThan(0);
    const attributes:Record<string,string>={},style:Record<string,string>={};
    for(const [,script] of scripts)runInNewContext(script,{
      document:{documentElement:{setAttribute:(key:string,value:string)=>{attributes[key]=value;},style}},
      localStorage:{getItem:(key:string)=>key==='pulseprep-theme'?stored:null},
      window:{matchMedia:()=>({matches:systemDark})},
    });
    expect(attributes['data-theme']).toBe(want);
    expect(style.colorScheme).toBe(want);
    expect(html).toContain('aria-label="Switch to dark mode"');
  });
});
